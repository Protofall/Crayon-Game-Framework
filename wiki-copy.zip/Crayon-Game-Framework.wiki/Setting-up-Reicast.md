When I tried to setup reicast, it was alot harder than the rest of the Dreamcast emulators, so I made some instructions and I want to include them here for those who want to use it

### Note: I was running Linux, Ubuntu 16.04 LTS when using Reicast

* I can't remember if this is still an issue with Master, but if you get a complain about `nullptr` being undefined, add `#define nullptr NULL` to core/imgread/common.h (Or replace all instances of nullptr with NULL in common.cpp)
* build shell/linux (`make`)
* copy final executable to main path (Rename if wish)
* `sudo usermod -a -G input USER` #In my case `USER` was david
* in shell/linux/tools open a terminal and type `sudo python2 reicast-joyconfig.py`
	1. Find the right device (In my case my keyboard is device 3)
	2. Enter key bindings as they appear (Note thumbstick won't map to keyboard so don't try to set them)
	3. Make a file of the suggested name in the suggested dir in `~/.local/share/reicast/mappings/` with the suggested text
* in ~/.config/reicast/emu.cfg set these vars
	1. enable_x11_keyboard = 0
	2. evdev_device_id_1 = 3
	3. Debug.SerialConsoleEnabled = 1


* To add a real BIOS, place your boot and flash.bin in these paths `~/.local/share/reicast/data/dc_boot.bin and ~/.local/share/reicast/data/dc_flash.bin`

* `man reicast` The source is at https://github.com/reicast/reicast-emulator/blob/master/shell/linux/man/reicast.1