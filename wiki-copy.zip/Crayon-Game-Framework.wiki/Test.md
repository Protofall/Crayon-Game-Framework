Just a test for later showing how to display gif's in markdown

![](https://cdn.discordapp.com/attachments/537283154873024539/537295783058341888/heavy_smash.gif)