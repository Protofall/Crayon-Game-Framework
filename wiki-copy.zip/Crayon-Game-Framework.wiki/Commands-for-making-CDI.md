Sometimes I want to manually convert an `.elf` file to a `.cdi`. These are the commands needed. Note the terminal should be in the same dir as 1st_read.bin when building the iso file and this assumes cdi4dc is in one of your profile paths.

```bash
PROG=""		#Name of your program ($PROG.elf)
IP_PATH=""	#The path to your IP.BIN file

sh-elf-objcopy -R .stack -O binary $PROG.elf $PROG.bin
$KOS_BASE/utils/scramble/scramble $PROG.bin 1st_read.bin
mkisofs -G $IP_PATH -C 0,11702 -J -l -r -o $PROG.iso .
cdi4dc $PROG.iso $PROG.cdi
```