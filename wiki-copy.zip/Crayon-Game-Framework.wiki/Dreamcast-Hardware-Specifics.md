Console:
* **CPU**: 200MHz
* **Main RAM**: 16MB
* **VRAM**: 8MB (About half of that is used up by KOS itself)
* **SRAM**: 2MB
* **Video output**: 640 x 480 Progressive Scan, RGB565 (Other resolutions/refresh rates are possible)

Other notes:
* Textures must have width and height of 2^n where n is a positive integer (This means all textures must be square). The maximum texture size is 1024 wide and high, any larger than this isn't supported. If you try to use/make a texture that has a width or height that isn't a multiple of two, when rendered the texture will appear to be all garbled up.

VMU:
* **VMU Storage**: 128KB
* **Block size**: 512B
* **LCD Dimensions**: 32 high, 48 wide, 1bpp (Without the greyscale trick)