If for whatever reason you don't have access to a Dreamcast console or don't have an easy way to test on your Dreamcast (SD/BBA methods), this is my guide for using emulators. Do note that every emulator is partially inaccurate so it is a good idea to test on real hardware every so often.

* **DEMUL** seems to be the best emulator choice to the most part with high compatibility, but it does have a few issues. It is Windows only

* **REDREAM** has a few mistakes in its emulation and some parts aren't emulated yet (Like mouse support), but it is a good second, is cross-platform and is actively developed and has a chance to overtake DEMUL.

* I haven't used **REICAST** enough to determine how good it is. It is a bit hard setting up basic things like controllers, but it does have the advantage of printf compatibility out of the box (Other emulators have this feature too, but you need to do some tricks to get it to work)

* **LXDREAM** has a lot of errors in its emulation, for example sometimes a cdi might behave randomly and crash and can be fixed by adding 10 random printf's, however its able to draw the BIOS font (Such as with `error_freeze()` ) and even picks up some details that no other emulator does (Such as trying to read a 2+ digit number from file into a `%hhu` (unsigned char). In this case the proper behaviour is to crash, but DEMUL and REDREAM keep going as if this isn't a problem)

Also note none of the currently available emulators support "Compressed and Paletted Textures" even though hardware does. The authors of DEMUL have shown me that their development version does handle this, but it isn't publically available yet with no release date planned for now.